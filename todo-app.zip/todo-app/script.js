// Fonction d'ajout de tâche
document.getElementById('addTaskBtn').addEventListener('click', function() {
  const taskInput = document.getElementById('taskInput');
  const taskText = taskInput.value.trim();

  if (taskText === '') return; // Si la tâche est vide, on ne fait rien

  // Créer un élément <li> pour la nouvelle tâche
  const li = document.createElement('li');
  li.innerHTML = `
    <span>${taskText}</span>
    <button class="delete">Supprimer</button>
    <button class="complete">Terminer</button>
  `;
  
  // Ajouter la tâche à la liste
  document.getElementById('taskList').appendChild(li);
  saveTasks(); // Sauvegarder les tâches

  taskInput.value = ''; // Réinitialiser l'input

  // Marquer la tâche comme terminée
  li.querySelector('.complete').addEventListener('click', function() {
    li.classList.toggle('completed');
    saveTasks(); // Sauvegarder après modification
  });

  // Supprimer la tâche
  li.querySelector('.delete').addEventListener('click', function() {
    li.classList.add('removing'); // Ajouter l'animation de suppression
    setTimeout(function() {
      li.remove(); // Retirer l'élément après l'animation
      saveTasks(); // Sauvegarder après suppression
    }, 300);
  });
});

// Charger les tâches depuis le localStorage lors du chargement de la page
window.onload = function() {
  loadTasks();
};

// Sauvegarder les tâches dans le localStorage
function saveTasks() {
  const tasks = [];
  const taskItems = document.querySelectorAll('#taskList li');

  taskItems.forEach(item => {
    tasks.push({
      text: item.querySelector('span').textContent,
      completed: item.classList.contains('completed')
    });
  });

  localStorage.setItem('tasks', JSON.stringify(tasks));
}

// Charger les tâches depuis le localStorage
function loadTasks() {
  const tasks = JSON.parse(localStorage.getItem('tasks'));
  if (tasks) {
    tasks.forEach(task => {
      const li = document.createElement('li');
      li.innerHTML = `
        <span>${task.text}</span>
        <button class="delete">Supprimer</button>
        <button class="complete">Terminer</button>
      `;
      if (task.completed) {
        li.classList.add('completed');
      }
      document.getElementById('taskList').appendChild(li);

      li.querySelector('.complete').addEventListener('click', function() {
        li.classList.toggle('completed');
        saveTasks();
      });

      li.querySelector('.delete').addEventListener('click', function() {
        li.classList.add('removing');
        setTimeout(function() {
          li.remove();
          saveTasks();
        }, 300);
      });
    });
  }
}
